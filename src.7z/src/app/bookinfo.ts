// tslint:disable-next-line: no-empty-interface
export interface Bookinfo {
    bookid: number;
    title: any;
    isbn: any;
    pagecount: any;
    publisheddate: any;
    thumbnailUrl: any;
    shortdescription: any;
    longdescription: any;
    state: any;
    authors: any;
    categories: any;
}
