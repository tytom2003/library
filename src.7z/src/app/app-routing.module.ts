import { LoginComponent } from './login/login.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { UsermgmtComponent } from './usermgmt/usermgmt.component';
import { BookmgmtComponent } from './bookmgmt/bookmgmt.component';
import { BooklistComponent } from './booklist/booklist.component';
import { BookingComponent } from './booking/booking.component';
import { EditbookinfoComponent } from './bookmgmt/editbookinfo/editbookinfo.component';
import { EdituserComponent } from './usermgmt/edituser/edituser.component';
import { UserchangedataComponent } from './userchangedata/userchangedata.component';
import { UserpageComponent } from './userpage/userpage.component';

const routes: Routes = [
  {path: 'register', component: RegisterComponent },
  {path: 'studmgmt', component:  UsermgmtComponent},
  {path: 'bookmgmt', component: BookmgmtComponent},
  {path: 'booklist', component: BooklistComponent},
  {path: 'booking', component: BookingComponent},
  {path: 'login', component: LoginComponent},
  {path: 'editbookinfo', component: EditbookinfoComponent},
  {path: 'edituserdata', component: EdituserComponent },
  {path: 'changeuserdata', component: UserchangedataComponent },
  {path: 'userpage', component: UserpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
