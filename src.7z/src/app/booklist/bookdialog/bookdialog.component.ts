import { Bookinfo } from './../../bookinfo';
import {  MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, OnInit, Inject, Input, Optional } from '@angular/core';

@Component({
  selector: 'app-bookdialog',
  templateUrl: './bookdialog.component.html',
  styleUrls: ['./bookdialog.component.scss']
})

export class BookdialogComponent implements OnInit {
  @Input() row: any[];
  dialogmessage: any;
  constructor(public dialogReg: MatDialogRef<BookdialogComponent>, @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
    this.dialogmessage = data.message;
    console.log(this.dialogmessage?.title);
  }

  ngOnInit(): void {

  }

}
