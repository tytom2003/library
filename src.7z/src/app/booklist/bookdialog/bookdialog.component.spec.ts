import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookdialogComponent } from './bookdialog.component';

describe('BookdialogComponent', () => {
  let component: BookdialogComponent;
  let fixture: ComponentFixture<BookdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
