import { LibraryserivceService } from './../libraryserivce.service';
import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortable } from '@angular/material/sort';
import { Observable } from 'rxjs/internal/Observable';
import { debounceTime, map } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BookdialogComponent } from './bookdialog/bookdialog.component';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.scss']
})
export class BooklistComponent implements OnInit {

  bookdata = new MatTableDataSource<any>();
  booktotalcount: number;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;
  posts$: Observable<any>;
  selectbookdata: any[];

  constructor(private http: HttpClient, private brow: LibraryserivceService, public dialog: MatDialog) { }

  ngOnInit(): void {

    this.http.get<any>('http://127.0.0.1/library/booklist.php/').subscribe(apidata => {
      this.bookdata = new MatTableDataSource<any>(apidata);
      this.booktotalcount = apidata.total_count;
      this.bookdata.paginator = this.paginator;
      this.bookdata.sort = this.sort;
  });

  }

  applyFilter(filterValue: any)
  {
    this.bookdata.filterPredicate = (data: any, filter: string): boolean => {
      const datastr = data.bookid + data.title + data.isbn + data.pagecount + data.publisheddate + data.authors + data.categories;
      return datastr.includes(filter);
    };

    this.bookdata.filter = filterValue;
  }

  openAlertDialog(emailRow) {
    const dialogRef = this.dialog.open(BookdialogComponent , {
      data: { message: emailRow,
      height: '600px',
      width: '600px' }
    });
  }

  reply(emailRow) {
    console.log('回覆信件', emailRow);
    this.selectbookdata = emailRow;
  }

  passdata(emailRow) {
    // console.log('回覆信件', emailRow);
     this.brow.addbookrow(emailRow);
  }

}
// https://github.com/wellwind/it-ironman-demo-angular-material/tree/day-17-card/src/app/dashboard/blog

// https://stackoverflow.com/questions/52656937/in-angular-7-how-do-i-populate-a-mat-table-with-a-data-from-an-object

// https://stackoverflow.com/questions/44995971/creating-grid-of-cards-dynamically-using-angular-material-2/55431231

// https://medium.com/javascript-in-plain-english/create-a-responsive-card-grid-in-angular-using-flex-layout-3d1b58411e7a

// https://blog.kevinyang.net/2018/09/19/angular-material-table-hidden-api/

// https://angular.tw/tutorial/toh-pt3
