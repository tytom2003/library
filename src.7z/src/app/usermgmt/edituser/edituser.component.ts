import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LibraryserivceService } from './../../libraryserivce.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.scss']
})
export class EdituserComponent implements OnInit {

  public userdata: any;
  userdataform: FormGroup;

  constructor(private formBulider: FormBuilder, private http: HttpClient, private router: Router,
              private libraryserivce: LibraryserivceService )
  {
    this.userdataform = this.formBulider.group
    ({
      firstname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      lastname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      birthday: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required, Validators.minLength(10)]),
      telnum: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]),
      email: new FormControl('', [Validators.required, Validators.email]),
      studid: new FormControl('', [Validators.required]),
      class: new FormControl('', [Validators.required]),
      password1: new FormControl('', [Validators.required, Validators.minLength(8)]),
      password2: new FormControl('', [Validators.required, Validators.minLength(8)])
    });
  }

  ngOnInit(): void {

    this.userdata = this.libraryserivce.getuserdata();
    // console.log(this.userdata);
    console.log(localStorage.getItem('usertype'));
    this.userdataform.patchValue({
      firstname: this.userdata.firstname,
      lastname: this.userdata.lastname,
      birthday: this.userdata.birthday,
      address: this.userdata.address,
      telnum: this.userdata.telnum,
      email: this.userdata.email,
      studid: this.userdata.studid,
      class: this.userdata.class,
      password1: this.userdata.password,
      password2: this.userdata.password,
    });
  }

  editdata()
  {
    const options = { responseType: 'text' as 'json'};

    const bookeditdata =
    {
      firstname: this.userdataform.value.firstname,
      lastname: this.userdataform.value.lastname,
      birthday: this.userdataform.value.birthday,
      address: this.userdataform.value.address,
      telnum: this.userdataform.value.telnum,
      email: this.userdataform.value.email,
      studid: this.userdataform.value.studid,
      class: this.userdataform.value.class,
      password: this.userdataform.value.password1,
      userno: this.userdata.userno
    };

    this.http.post('http://127.0.0.1/library/edituser.php', JSON.stringify(bookeditdata), options)
    .subscribe( (bookediteddata: any) => {
    this.router.navigateByUrl('studmgmt');
    });
  }

  equalPasswords(): boolean {

    const matched: boolean = this.userdataform.get('password1').value !== this.userdataform.get('password2').value;

    return matched;
}// end of equalPasswords();

}
