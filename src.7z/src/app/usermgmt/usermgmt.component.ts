import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortable } from '@angular/material/sort';
import { LibraryserivceService } from './../libraryserivce.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usermgmt',
  templateUrl: './usermgmt.component.html',
  styleUrls: ['./usermgmt.component.scss']
})
export class UsermgmtComponent implements OnInit {

  userdata = new MatTableDataSource<any>();
  usertotalcount: number;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;

  constructor( private http: HttpClient, private router: Router, private libraryservice: LibraryserivceService  ) { }

  ngOnInit(): void {
    // tslint:disable-next-line: deprecation
    this.http.get<any>('http://127.0.0.1/library/userdata.php/').subscribe(apidata => {
      this.userdata = new MatTableDataSource<any>(apidata);
      this.usertotalcount = apidata.total_count;
      this.userdata.paginator = this.paginator;
      this.userdata.sort = this.sort;
      console.log(apidata);
    });
  }

  applyFilter(filterValue: any)
  {
    this.userdata.filterPredicate = (data: any, filter: string): boolean => {
      const datastr = data.studid + data.firstname + data.lastname + data.telnum + data.email + data.class;
      return datastr.includes(filter);
    };

    this.userdata.filter = filterValue;

  }

  edituser(urow) {
    this.libraryservice.adduserdata(urow);
    this.router.navigateByUrl('edituserdata');
    // console.log('回覆信件', emailRow);
  }

  delete(emailRow) {
    console.log('刪除信件', emailRow);
  }


}

/*
https://www.tutorialspoint.com/angular_material7/angular_material7_paginator.htm
https://stackoverflow.com/questions/47588162/how-to-add-all-option-for-angular-material-paginator
https://www.semicolonworld.com/question/70413/how-to-change-the-content-of-pagesizeoptions-in-material-paginator
https://github.com/bvaughn/infinite-list-reflow-examples
http://www.techbrothersit.com/2018/11/how-to-import-json-file-to-mysql-table.html
https://numidian.io/pricing
https://morioh.com/p/33d0377536a6

*/
