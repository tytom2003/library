import { Injectable } from '@angular/core';
import {BehaviorSubject, ReplaySubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LibraryserivceService {

  private bookrow: BehaviorSubject<any[]> = new BehaviorSubject([]);
  private newbookrow: BehaviorSubject<any[]> = new BehaviorSubject([]);
  currentbooking = this.bookrow.asObservable();

  public bookingbook: any[] = [];
  public filterbook: any[];
  public newbookarray: any[];
  public newbookingbook: any[];
  public bookdetail: any;
  public udata: any;
  constructor() { }

  addbookrow(row: any)
  {
    this.bookingbook.push(row);
    this.bookingbook = this.bookingbook.filter((test, index, array) => index === array.findIndex((findTest) =>
    findTest.bookid === test.bookid));
   // console.log(this.bookingbook);
  }

  getbookrow()
  {
    // console.log(this.bookingbook);
    return this.bookingbook;
  }

  addeditbookinfo(bookinfo: any)
  {
     this.bookdetail = bookinfo;
  }

  getbookinfo()
  {
    return this.bookdetail;
  }

  adduserdata(userdata: any)
  {
    this.udata = userdata;
  }

  getuserdata()
  {
    return this.udata;
  }

  setToken(token: string, usertype: string) {
    localStorage.setItem('usertype', usertype);
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  deleteToken() {
    localStorage.removeItem('usertype');
    localStorage.removeItem('token');
  }

  isLoggedIn() {
    const usertoken = this.getToken();
    if (usertoken != null) {
      return true;
    }
    return false;
  }

}

/*
https://fireship.io/lessons/sharing-data-between-angular-components-four-methods/
*/

/*
shopping cart
https://angular.io/start/start-data
*/

/*
array delete data
https://stackoverflow.com/questions/40462369/remove-item-from-stored-array-in-angular-2/40462431

https://www.tutorialspoint.com/typescript/typescript_array_splice.htm

https://www.tutorialspoint.com/typescript/typescript_array_splice.htm

https://stackoverflow.com/questions/1232040/how-do-i-empty-an-array-in-javascript

https://ithelp.ithome.com.tw/articles/10136957
*/

/*
How to remove duplicate object from an array in angular 6

https://stackoverflow.com/questions/53637425/how-to-remove-duplicate-object-from-an-array-in-angular-6
*/
