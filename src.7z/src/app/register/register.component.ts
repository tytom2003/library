import { LibraryserivceService } from './../libraryserivce.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import * as moment from 'moment';
import { equal } from 'assert';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  static register: any;
  // tslint:disable-next-line: ban-types
  public pwd1: String;
  // tslint:disable-next-line: ban-types
  public pwd2: String;

  constructor(private formBulider: FormBuilder, private router: Router, private http: HttpClient,
              private libraryservice: LibraryserivceService ) {
    this.register = this.formBulider.group({
      firstname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      lastname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      birthday: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required, Validators.minLength(10)]),
      telnum: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]),
      email: new FormControl('', [Validators.required, Validators.email]),
      studid: new FormControl('', [Validators.required]),
      class: new FormControl('', [Validators.required]),
      password1: new FormControl('', [Validators.required, Validators.minLength(8)]),
      password2: new FormControl('', [Validators.required, Validators.minLength(8)])
    });
  }

  register: FormGroup;

  equalPasswords(): boolean {

    const matched: boolean = this.register.get('password1').value !== this.register.get('password2').value;

    return matched;
}// end of equalPasswords();
/*
  equalPasswords() {
    this.pwd1 = this.register.get('password1').value.toString();
    this.pwd2 = this.register.get('password2').value.toString();
    if (this.pwd1 === this.pwd2)
     {
        // control.get('password2').setErrors({passwordnotmatch: true});
        console.log(this.register.get('password1').value);
        console.log(this.register.get('password2').value);
        return true;
     }
     else
     {
       return false;
     }
}
*/
  ngOnInit(): void {
    console.log(this.libraryservice.getToken());
  }// end of ngOnInit()
// end of equalPasswords();

  adduserdata()
  {
    const options = { responseType: 'text' as 'json'};
    const registerdata = new FormData();
    registerdata.append('firstname', this.register.value.firstname);
    registerdata.append('lastname', this.register.value.lastname);
    registerdata.append('birthday', this.register.value.birthday._i);
    registerdata.append('address', this.register.value.address);
    registerdata.append('telnum', this.register.value.telnum);
    registerdata.append('email', this.register.value.email);
    registerdata.append('studid', this.register.value.studid);
    registerdata.append('class', this.register.value.class);
    registerdata.append('password1', this.register.value.password1);
    // console.log(this.register.value.birthday);
    // console.log(this.register.value.birthday._i);
  // console.log(this.register.value.firstname);
  // console.log(' addUserdata ');
  // console.log(registerdata);


    return this.http.post('http://127.0.0.1/library/adduserdata.php/', registerdata, options)
    // tslint:disable-next-line: deprecation
    .subscribe((res: Response) => {this.router.navigateByUrl('login'); });
  }
}// end of export class RegisterComponent implements OnInit()
/*
https://stackoverflow.com/questions/52480822/angular-material-mat-error-not-showing-despite-true-methods/52481761
https://angular.tw/tutorial/toh-pt5
https://stackoverflow.com/questions/52673691/form-submit-with-angular-material

D:\desktop\student\src\app\adduser

https://medium.com/@ole.ersoy/closing-the-angular-material-sidenav-post-navigation-ce428d10fb4b

https://stackblitz.com/edit/angular-mat-form-validation-eg?file=app%2Finput-error-state-matcher-example.ts
https://www.itsolutionstuff.com/post/angular-validation-password-and-confirm-passwordexample.html
*/
