import { MatTableDataSource } from '@angular/material/table';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { LibraryserivceService } from './../libraryserivce.service';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent {

  public bookingbook: any[];
  public filterbook: any[];
  public newbookarray: any[];
  public obbookingbook: Observable<any[]>;
  public datasource: any[] = [];

  constructor(private http: HttpClient, private brow: LibraryserivceService, private cdr: ChangeDetectorRef) {

   }

  // tslint:disable-next-line: use-lifecycle-interface
  ngOnInit(): void {
    this.bookingbook = this.brow.getbookrow();
    // this.cdr.detectChanges();
    //
    console.log(this.bookingbook);
    // console.log('booking:' + this.brow.getbookrow());
  }

  delete(row: any)
  {
    let num: any = 0;
    // console.log(row);

    // tslint:disable-next-line: prefer-for-of
    for (let x = 0; x < this.bookingbook.length; x++)
    {
      if (row.bookid === this.bookingbook[x].bookid)
      {
        console.log(x);
        // delete this.bookingbook[x];
       // this.bookingbook.splice(x, 1);
        this.brow.bookingbook.splice(x, 1);
       // continue;
      }
      if (this.brow.bookingbook[x] !== undefined)
      {
        this.datasource.push(this.brow.bookingbook[x]);
      }
    }
    console.log(this.datasource);
    console.log('length :' + this.datasource.length);
    this.bookingbook = [];
    this.brow.bookingbook = [];
    this.brow.bookingbook = this.datasource;
    this.bookingbook = this.datasource;
    console.log(this.brow.bookingbook);
    this.datasource = [];
    this.bookingbook = [...this.bookingbook];
  }
}
// https://www.encodedna.com/javascript/remove-duplicates-in-javascript-array-using-es6-set-and-from.htm
// https://stackoverflow.com/questions/54098149/removing-duplicates-with-is-an-object-array-using-angular-4/54098477

/*
login
https://jonny-huang.github.io/angular/training/32_rxjs_6/
https://blog.yang-hong-xin.com/using-rxjs-this-way-in-angular/
https://www.usefuldev.com/post/Typescript:%20filtering%20an%20array%20for%20distinct%20values
*/

/*
Observable Arrays
https://knockoutjs.com/documentation/observableArrays.html

https://stackoverflow.com/questions/53260269/angular-6-add-items-into-observable

https://mobx.js.org/refguide/map.html

https://ithelp.ithome.com.tw/articles/10187005


detect change.
https://ithelp.ithome.com.tw/articles/10209026
https://stackblitz.com/edit/ironman2019-change-detector-ref?file=src%2Fapp%2Fapp.component.ts
*/
