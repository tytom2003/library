import { LibraryserivceService } from './libraryserivce.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegisterComponent } from './register/register.component';
import { UsermgmtComponent } from './usermgmt/usermgmt.component';
import { BookmgmtComponent } from './bookmgmt/bookmgmt.component';
import { BooklistComponent } from './booklist/booklist.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatMomentDateModule} from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { HeaderComponent } from './header/header.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { HttpClientModule } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BookdialogComponent } from './booklist/bookdialog/bookdialog.component';
import { BookingComponent } from './booking/booking.component';
import { LoginComponent } from './login/login.component';
import { EditbookinfoComponent } from './bookmgmt/editbookinfo/editbookinfo.component';
import { EdituserComponent } from './usermgmt/edituser/edituser.component';
import { UserchangedataComponent } from './userchangedata/userchangedata.component';
import { UserpageComponent } from './userpage/userpage.component';

export const TW_FORMATS = {
  parse: {
    dateInput: 'YYYY/MM/DD'
  },
  display: {
    dateInput: 'YYYY/MM/DD',
    monthYearLabel: 'YYYY MMM',
    dateA11yLabel: 'YYYY/MM/DD',
    monthYearA11yLabel: 'YYYY MMM'
  }
};

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HeaderComponent,
    UsermgmtComponent,
    BookmgmtComponent,
    BooklistComponent,
    BookdialogComponent,
    BookingComponent,
    LoginComponent,
    EditbookinfoComponent,
    EdituserComponent,
    UserchangedataComponent,
    UserpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatSnackBarModule
  ],
  providers: [ {provide: MAT_DATE_LOCALE, useValue: 'zh-TW'},
               { provide: MAT_DATE_FORMATS, useValue: TW_FORMATS },
               { provide: MAT_DIALOG_DATA, useValue: {} },
               { provide: MatDialogRef, useValue: {} }
],
  bootstrap: [AppComponent]
})
export class AppModule { }
