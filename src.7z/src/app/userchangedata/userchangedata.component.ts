import { Component, OnInit } from '@angular/core';
import { LibraryserivceService } from './../libraryserivce.service';
import { FormControl, FormGroup, Validators, FormBuilder, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

@Component({
  selector: 'app-userchangedata',
  templateUrl: './userchangedata.component.html',
  styleUrls: ['./userchangedata.component.scss']
})
export class UserchangedataComponent implements OnInit {

  static changeuserform: any;
  changeuserform: FormGroup;
  public userno: any;
  public getapiuserdata: any;

  constructor(private formBulider: FormBuilder, private router: Router, private http: HttpClient,
              private libraryservice: LibraryserivceService )
  {
    this.changeuserform = this.formBulider.group({
      firstname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      lastname: new FormControl('', [Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z]+')]),
      birthday: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required, Validators.minLength(10)]),
      telnum: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]),
      email: new FormControl('', [Validators.required, Validators.email]),
      studid: new FormControl('', [Validators.required]),
      class: new FormControl('', [Validators.required]),
      password1: new FormControl('', [Validators.required, Validators.minLength(8)]),
      password2: new FormControl('', [Validators.required, Validators.minLength(8)])
    });
  }

  equalPasswords(): boolean {

    const matched: boolean = this.changeuserform.get('password1').value !== this.changeuserform.get('password2').value;

    return matched;
}// end of equalPasswords();

  ngOnInit(): void {
    this.userno = this.libraryservice.getToken();
    console.log(this.userno);

    const options = { responseType: 'text' as 'json'};
    const usernodata = { userno: this.userno, getuserdata: '1'};

    this.http.post('http://127.0.0.1/library/edituser.php', JSON.stringify(usernodata), options)
    .subscribe((apiuserdata: any) => {
    // console.log(apiuserdata);
      this.getapiuserdata = JSON.parse(apiuserdata);
      this.changeuserform.patchValue({
        firstname: this.getapiuserdata[0].firstname,
        lastname: this.getapiuserdata[0].lastname,
        birthday: this.getapiuserdata[0].birthday,
        address: this.getapiuserdata[0].address,
        telnum: this.getapiuserdata[0].telnum,
        email: this.getapiuserdata[0].email,
        studid: this.getapiuserdata[0].studid,
        class: this.getapiuserdata[0].class,
        password1: this.getapiuserdata[0].password,
        password2: this.getapiuserdata[0].password,
      });
    });

  }// end of ngOnInit(): void

  editdata()
  {
    const options = { responseType: 'text' as 'json'};

    const bookeditdata =
    {
      firstname: this.changeuserform.value.firstname,
      lastname: this.changeuserform.value.lastname,
      birthday: this.changeuserform.value.birthday,
      address: this.changeuserform.value.address,
      telnum: this.changeuserform.value.telnum,
      email: this.changeuserform.value.email,
      studid: this.changeuserform.value.studid,
      class: this.changeuserform.value.class,
      password: this.changeuserform.value.password1,
      userno: this.getapiuserdata[0].userno
    };

    this.http.post('http://127.0.0.1/library/edituser.php', JSON.stringify(bookeditdata), options)
    .subscribe( (bookediteddata: any) => {
    this.router.navigateByUrl('studmgmt');
    });
  }// end of editdata()

  }

