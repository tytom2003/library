import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserchangedataComponent } from './userchangedata.component';

describe('UserchangedataComponent', () => {
  let component: UserchangedataComponent;
  let fixture: ComponentFixture<UserchangedataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserchangedataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserchangedataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
