import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, MatSortable } from '@angular/material/sort';
import { LibraryserivceService } from './../libraryserivce.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bookmgmt',
  templateUrl: './bookmgmt.component.html',
  styleUrls: ['./bookmgmt.component.scss']
})
export class BookmgmtComponent implements OnInit {

  bookdata = new MatTableDataSource<any>();
  booktotalcount: number;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;

  constructor(private http: HttpClient, private router: Router, private libraryserivce: LibraryserivceService ) { }

  ngOnInit(): void {
    /*
    this.http.get<any>('assets/books.json')
    .subscribe(data => {
      this.bookdata = new MatTableDataSource<any>(data);
      this.booktotalcount = data.total_count;
      this.bookdata.paginator = this.paginator;
      this.bookdata.sort = this.sort;
      console.log(data);
    });
    */
   this.http.get<any>('http://127.0.0.1/library/bookdata.php/').subscribe(apidata => {
    this.bookdata = new MatTableDataSource<any>(apidata);
    this.booktotalcount = apidata.total_count;
    this.bookdata.paginator = this.paginator;
    this.bookdata.sort = this.sort;

  });
  }

  applyFilter(filterValue: any)
  {
    this.bookdata.filterPredicate = (data: any, filter: string): boolean => {
      const datastr = data.bookid + data.title + data.isbn + data.pagecount + data.publisheddate + data.authors + data.categories;
      return datastr.includes(filter);
    };

    this.bookdata.filter = filterValue;

  }

  reply(emailRow) {
    this.libraryserivce.addeditbookinfo(emailRow);
    this.router.navigateByUrl('editbookinfo');
    // console.log('回覆信件', emailRow);
  }

  disablebook(emailRow) {
    const options = { responseType: 'text' as 'json'};
    console.log(emailRow.bookid);
    const bookdata = {bookid: emailRow.bookid,
                      disablebook: '1'};

    this.http.post('http://127.0.0.1/library/editbook.php', JSON.stringify(bookdata), options)
    .subscribe( (bookediteddata: any) => {
    this.getdata();
    });
    // console.log('刪除信件', emailRow);
  }

  getdata()
  {
    this.http.get<any>('http://127.0.0.1/library/bookdata.php/').subscribe(apidata => {
      this.bookdata = new MatTableDataSource<any>(apidata);
      this.booktotalcount = apidata.total_count;
      this.bookdata.paginator = this.paginator;
      this.bookdata.sort = this.sort;
    });
  }
}
