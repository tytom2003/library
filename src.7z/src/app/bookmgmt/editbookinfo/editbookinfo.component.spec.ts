import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditbookinfoComponent } from './editbookinfo.component';

describe('EditbookinfoComponent', () => {
  let component: EditbookinfoComponent;
  let fixture: ComponentFixture<EditbookinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditbookinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditbookinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
