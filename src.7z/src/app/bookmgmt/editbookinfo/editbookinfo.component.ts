import { Component, OnInit } from '@angular/core';
import { LibraryserivceService } from './../../libraryserivce.service';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-editbookinfo',
  templateUrl: './editbookinfo.component.html',
  styleUrls: ['./editbookinfo.component.scss']
})

export class EditbookinfoComponent implements OnInit {
  static editbookinfo: any;
  public bookinfo: any;
  editbookinfo: FormGroup;

  constructor(private formBulider: FormBuilder, private router: Router, private http: HttpClient,
              private libraryservic: LibraryserivceService)
  {
    this.editbookinfo = this.formBulider.group(
      {
      author: new FormControl('', [Validators.required]),
      categories: new FormControl('', [Validators.required]),
      isbn: new FormControl('', [Validators.required]),
      pagecount: new FormControl('', [Validators.required]),
      publisheddate: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required]),
      shortdescription: new FormControl('', [Validators.required]),
      status: new FormControl('', [Validators.required]),
      thumbnailurl: new FormControl('', [Validators.required]),
      title: new FormControl('', [Validators.required])
    }); // end of this.formBulider.group
  }// end of constructor



  ngOnInit(): void {
    this.bookinfo = this.libraryservic.getbookinfo();

    this.editbookinfo.patchValue({
      title: this.bookinfo.title,
      author: this.bookinfo.authors,
      isbn: this.bookinfo.isbn,
      pagecount: this.bookinfo.pagecount,
      publisheddate: this.bookinfo.publisheddate,
      categories: this.bookinfo.categories,
      status: this.bookinfo.status,
      thumbnailurl: this.bookinfo.thumbnailUrl,
      description: this.bookinfo.longDescription
    });
   // this.editbookinfo.value.title = this.bookinfo.title;
  }// end of ngOnInit

  editbook()
  {
    const options = { responseType: 'text' as 'json'};

    const bookeditdata = {title: this.editbookinfo.value.title,
                   author: this.editbookinfo.value.author,
                   isbn: this.editbookinfo.value.isbn,
                   pagecount: this.editbookinfo.value.pagecount,
                   publisheddate: this.editbookinfo.value.publisheddate,
                   categories: this.editbookinfo.value.categories,
                   status: this.editbookinfo.value.status,
                   thumbnailurl: this.editbookinfo.value.thumbnailurl,
                   description: this.editbookinfo.value.description,
                   bookid: this.bookinfo.bookid,
                   editbook: '1'
                };

    this.http.post('http://127.0.0.1/library/editbook.php', JSON.stringify(bookeditdata), options)
    .subscribe( (bookediteddata: any) => {
    this.router.navigateByUrl('bookmgmt');
    });
  }// end of editbook()
}// end of export class EditbookinfoComponent implements OnInit
