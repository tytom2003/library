import { Component, OnInit } from '@angular/core';
import { LibraryserivceService } from './libraryserivce.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'librarysys';
  public utype: any;

  constructor(private router: Router, private libraryservice: LibraryserivceService )
  {

  }

  ngOnInit(): void {
    this.utype = localStorage.getItem('usertype');
  }


  logOut()
  {
    this.libraryservice.deleteToken();
    this.router.navigateByUrl('login');
  }
    }
/*
https://loiane.com/2017/08/angular-hide-navbar-login-page/
https://stackoverflow.com/questions/59329306/angular-material-add-sidenav-to-just-a-few-pages
https://stackoverflow.com/questions/50124558/how-to-use-different-navbar-for-different-type-of-user-in-angular-5-4
https://godbasin.github.io/front-end-playground/front-end-others/angular-free/4-create-sidebar.html#%E5%88%9B%E5%BB%BA%E5%B7%A6%E4%BE%A7%E8%8F%9C%E5%8D%95
https://juejin.im/post/6844903933589061639

https://www.cnblogs.com/danvic712/p/angular-components-guide.html
https://stackoverflow.com/questions/47611423/angular-routing-views-for-different-users

https://stackoverflow.com/questions/55365464/same-url-path-but-loading-different-components-based-on-user-role-angular

https://medium.com/@ryanchenkie_40935/angular-authentication-using-route-guards-bf7a4ca13ae3
https://ithelp.ithome.com.tw/articles/10213756

https://stackoverflow.com/questions/44719324/angular-hide-guarded-links-in-template

https://stackoverflow.com/questions/47143778/best-way-to-show-hide-a-link-in-angular-5

https://www.digitalocean.com/community/tutorials/angular-route-guards

https://codecraft.tv/courses/angular/routing/router-guards/

https://cloud.tencent.com/developer/section/1489557

https://pvt5r486.github.io/f2e/20190609/1487025750/

https://www.itread01.com/content/1549806525.html
https://www.itread01.com/content/1554367336.html

https://stackoverflow.com/questions/40507064/how-to-hide-link-by-guard-angular2

https://thinkster.io/tutorials/building-real-world-angular-2-apps/authentication-based-directives
*/


