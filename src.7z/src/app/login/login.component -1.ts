import { LibraryserivceService } from './../libraryserivce.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpParams, HttpHeaders, HttpErrorResponse} from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { of, throwError } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  login: FormGroup;
  public uemail: any;
  message: string[] = [];

  constructor(private formBulider: FormBuilder, private router: Router, private http: HttpClient,
              private libraryservice: LibraryserivceService)
  {
    this.login = this.formBulider.group({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(8)])
    });
  }



  ngOnInit(): void {
  }

  userlogin()
  {
    const options = { responseType: 'text' as 'json'};
    const logindata = new FormData();
    const email = this.login.value.email;
    const password = this.login.value.password;
    console.log(this.login.value.email);
    console.log(this.login.value.password);


    this.http.post('http://127.0.0.1/library/login.php', {email, password}, options)
    .pipe(
      tap(_ => this.message.push('fetched data')),
      catchError(error => of(error)),
      map(user => {
        if (user.bearerToken)
        {
          console.log('testing');
        }
        else{
          console.log('error');
        }
        console.log(user);
     // console.log(this.message);
}
),
catchError(this.handleError)
// ) .subscribe((result) => {console.log(result); }
);

/*
this.http.post('http://127.0.0.1/library/login.php', {email, password}, options)
.pipe(map(user => {
  // localStorage.setItem('currentUser', JSON.stringify(user));
  console.log(user);
  // this.libraryservice.setToken(user[0].name);
  // console.log(this.libraryservice.getToken());
// this.getLoggedInName.emit(true);
}));
*/

}// end of ngInit()

// https://www.mtutorial.com/angular-login-logout-registration-example-php-api

// https://dzone.com/articles/create-a-beautiful-login-form-with-angular-material

handleError(error: HttpErrorResponse) {
  let errorMessage = 'Unknown error!';
  if (error.error instanceof ErrorEvent) {
    // Client-side errors
    errorMessage = `Error: ${error.error.message}`;
  } else {
    // Server-side errors
    errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  }
  window.alert(errorMessage);
  return throwError(errorMessage);
}


}
// https://my.oschina.net/u/4389301/blog/3380405
// https://dotblogs.com.tw/Sarah/2020/07/15/182543
// https://www.techiediaries.com/handle-angular-9-8-7-httpclient-errors-with-rxjs-catcherror-and-throwerror/
// https://forum.angular.tw/t/topic/1880
