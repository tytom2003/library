import { Component, OnInit } from '@angular/core';
import { LibraryserivceService } from '../libraryserivce.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.scss']
})
export class UserpageComponent implements OnInit {

  constructor(private router: Router, private libraryservice: LibraryserivceService) { }

  ngOnInit(): void {
  }

  logOut()
  {
    this.libraryservice.deleteToken();
    this.router.navigateByUrl('login');
  }
}
