import { TestBed } from '@angular/core/testing';

import { LibraryserivceService } from './libraryserivce.service';

describe('LibraryserivceService', () => {
  let service: LibraryserivceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LibraryserivceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
